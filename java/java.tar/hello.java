class hello{
public static void main(String[] args){
int num=5;
double a=num;
System.out.println("Hello"+a);
}
}
